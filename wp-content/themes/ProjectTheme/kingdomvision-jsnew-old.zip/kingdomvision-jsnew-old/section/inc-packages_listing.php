<?php
// ============================================================================
// LOAD CONFIGURATION & HELPER FUNCTIONS
// ============================================================================
require_once get_template_directory() . '/section/accommodation-config.php';

// ============================================================================
// INITIALIZE SETTINGS
// ============================================================================
$main_title    = $section['main_title'] ?: 'Browse Accommodation';
$content       = $section['content'] ?: '';
$category      = $section['select_category'] ?? null;
$product_count = (int) ($section['product_count'] ?: 6);

// Parse category info
$category_info = parse_accommodation_category($category);
$category_id   = $category_info['id'];
$category_slug = $category_info['slug'];
$category_name = $category_info['name'];

// Build tax query
$tax_query = [];
if ($category_id && is_int( $category_id )) {
    $tax_query[] = [
        'taxonomy' => 'accommodation-cat',
        'field'    => 'term_id',
        'terms'    => $category_id,
    ];
}

// Get URL path info for scoped filters
$path_segments = get_url_path_segments();
[$resort, $acc, $area] = array_pad($path_segments, 3, null);

if(@$_GET['gall'] == 'yes'){
    pre('resort');
    pre($resort);
    pre('acc');
    pre($acc);
    pre('area');
    pre($area);
}

// Get filter input values
$filter_inputs = get_filter_input_values();

// Get all options for filters
$resort_terms   = get_resort_terms();
$base_areas     = get_accommodation_base_areas( $resort !== 'accommodation' ? $resort.'-accommodation' : '' );
$bedroom_options = get_accommodation_bedroom_options();
$area_options   = get_accommodation_area_options();
$type_options   = get_accommodation_type_options();

// Apply defaults
$selected_bedrooms = $filter_inputs['bedrooms'];
$selected_areas    = $filter_inputs['areas'];
$selected_resort   = $filter_inputs['resort'];
$selected_types    = $filter_inputs['types'];
$price_min         = $filter_inputs['price_min'];
$price_max         = $filter_inputs['price_max'];

    $price_max = isset($_POST['price_max']) && $_POST['price_max'] !== ''
    ? (int) $_POST['price_max']
        : 1000000; // ✅ up to ¥1,000,000

    $slug = get_post_field( 'post_name');

    $url = wp_make_link_relative(get_permalink());

    // Build initial search parameters based on URL segments and context
    $search_params = [
        'category_slug' => $category_slug,
        'page'          => 1,
    ];

    // Determine the context segment based on URL structure
    // /accommodation/{type}/  OR  /{resort}/accommodation/{area}/
    $context_segment = ($resort === 'accommodation') ? $acc : $area;

    // Handle Area specific context and mappings
    if ($context_segment) {
        if ($context_segment === 'deals' || $context_segment === 'offers') {
            $search_params['discount'] = 1;
        } elseif ($context_segment === 'ski-in-ski-out') {
            $search_params['ski_in_ski_out'] = 1;
        } elseif ($context_segment === 'onsen') {
            $search_params['onsen'] = 1;
        } elseif ($context_segment === 'instant-booking') {
            $search_params['booking'] = 1;
        } else {
            // Check if $area is actually a property type slug first
            if (isset($type_options[$context_segment])) {
                $search_params['accommodation_type'] = [$context_segment];
            } else {
                $mapped_area = $context_segment;
                // Mapping URL segments to database term slugs as per filter logic
                if ($context_segment === 'niseko-village') $mapped_area = 'niseko-village-higashiyama';
                if ($context_segment === 'happo') $mapped_area = 'happo-one-village';
                if ($context_segment === 'wadano') $mapped_area = 'wadano_no_mori';
                if ($context_segment === 'hirafu') $mapped_area = 'hirafu_village';
                
                $search_params['areas'] = [$mapped_area];
            }
        }
    }

    // Handle Resort specific context (e.g., global offers page)
    if ($resort === 'offers') {
        $search_params['discount'] = 1;
    }

    $initial_args = niseko_build_search_query_args(
        $search_params,
        [
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ]
    );
    
    $initial_query = new WP_Query($initial_args);
    $initial_property_count = (int) ($initial_query->found_posts ?? 0);
    $initial_room_count = 0;

    if (!empty($initial_query->posts)) {
        $hotel_ids = [];
        foreach ($initial_query->posts as $post) {
            $hotel_id = get_field('acc_hotel_id', $post->ID);
            if (!empty($hotel_id)) {
                $hotel_ids[] = $hotel_id;
            }
        }

        if (!empty($hotel_ids)) {
            $room_args = [
                'post_type'      => 'japan_rooms',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [
                    [
                        'key'     => 'room_hotel_id',
                        'value'   => $hotel_ids,
                        'compare' => 'IN',
                    ],
                ],
            ];

            $room_query = new WP_Query($room_args);
            $initial_room_count = (int) ($room_query->found_posts ?? 0);
            wp_reset_postdata();
        }
    }
    echo '<section ' . SectionAttributes($section, 'full-section package_listing') . '>';

    ?>
        <div class="container">
            <div class="accom-search-wrapper">

                <h2><?php echo esc_html($main_title); ?></h2>
                <?php
                if ($content) {
                    echo '<div class="desc">' . $content . '</div>';
                }
                ?>
                <div class="accom-filters">
                    <!-- SEARCH FORM -->
                    <form id="accom-search-form" data-cat="<?php echo $category_slug ?>" per_page="<?php echo $product_count ?>">
                        <!-- TOOLBAR -->
                        <div class="results-toolbar">

                            <span class="results-count">
                                <strong id="rooms-count"><?php echo esc_html($initial_room_count); ?></strong>
                                stays across <span id="properties-count"><?php echo esc_html($initial_property_count); ?></span> properties
                            </span>
                            <span class="result-message">Showing accommodation from our portfolio</span>

                            <div id="selected-filter-template" style="display:none;">
                                <span class="filter">
                                    <a href="javascript:void(0);" 
                                    class="filter-tab active"
                                    data-type=""
                                    data-value=""></a>
                                    <span class="close_filter"></span>
                                </span>
                            </div>

                            <div class="toolbar-right">
                                <a href="javascript:;" class="toolbar-btn" id="open-filter">Filter by</a>

                            </div>

                        </div>

                    </form>

                    <div class="filter-tabs">

                        <span class="filter" style="display:none;">
                            <a type="button" class="filter-tab active reset">Reset</a>
                        </span>

                    </div>
                </div>
                <!-- RESULTS -->
                <div id="accom-search-results" style="display: none;">
                    <?php
                    if ($initial_query->have_posts()) {
                        while ($initial_query->have_posts()) {
                            $initial_query->the_post();
                            get_template_part('partials/accommodation-box');
                        }
                    } else {
                        echo '<p class="no-results">No accommodation found.</p>';
                    }
                    wp_reset_postdata();
                    ?>
                </div>

                <div class="load-more-wrap">
                    <button
                    type="button"
                    id="load-more"
                    class="load-more-btn"
                    data-page="1"
                    style="display:none;"">
                    Load More
                </button>
            </div>

        </div>
        </div>
    </section> <!-- package_listing -->
    <div id="filter-panel" class="filter-panel">

        <!-- HEADER -->
        <div class="filter-header">
            <h3>Filters</h3>
            <button type="button" id="close-filter">Close</button>
        </div>

        <div class="filter-body">

            <?php $display = should_display_resort_filter($resort) ? 'block' : 'none'; ?>
            <!-- RESORT -->
            <div class="filter-accordion resort active" style="display:<?php echo $display ?>">
                <h3 class="accordion-header">
                    Resort
                    <span class="accordion-icon"></span>
                </h3>

                <div class="accordion-content">
                    <div class="checkbox-grid">

                        <!-- All Resorts option -->
                        <div class="ch-item">
                            <input type="radio"
                            name="resort" 
                            class="js-sb-resort"
                            data-type="resort"
                            id="resort-all"
                            value="">
                            <label for="resort-all">
                                All Resorts
                            </label>
                        </div>

                        <?php foreach ($resort_terms as $term) :
                            $resort_slug = str_replace('-accommodation', '', $term->slug) ?>
                            <div class="ch-item">
                                <input type="radio"
                                name="resort"
                                data-type="resort" 
                                class="js-sb-resort"
                                id="resort-<?php echo esc_attr($term->slug); ?>"
                                value="<?php echo esc_attr($term->slug); ?>"
                                <?php checked($selected_resort, $resort_slug, true); ?>>
                                <label for="resort-<?php echo esc_attr($term->slug); ?>">
                                    <?php echo str_replace(ucwords(' accommodation'), '', esc_html($term->name)); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
            </div>

            <!-- PROPERTY -->
            <div class="filter-accordion resort active">
                <h3 class="accordion-header">
                     Property
                    <span class="accordion-icon"></span>
                </h3>
                <div class="accordion-content">
                    <!-- <div class="checkbox-grid"> -->
                        <!-- All Resorts option -->
                        <div class="property-search">
                            <input type="text" name="location" id="search_acc" placeholder="Enter property name">
                            <button class="clear_loc" style="display:none;"><i class="fa-solid fa-x"></i></button>
                            <input type="hidden" name="category_id" value="<?php echo esc_attr($category_id); ?>">
                            <input type="hidden" name="category_slug" value="<?php echo esc_attr($category_slug); ?>">
                        </div>
                        <div class="dropdown_results" style="display: none;">
                            <ul class="properties">
                                <?php foreach ($acc_ids as $key => $value):
                                    $title = get_the_title($value);
                                    $property_id = get_field( 'property_id', $value );
                                ?>
                                    <li data-value="<?php echo $title ?>" data-id="<?php echo $property_id ?>" class="property"><?php echo ucwords( $title ) ?></li>
                                <?php endforeach ?>
                           </ul>
                        </div>
                    <!-- </div> -->
                </div>
            </div>

            <!-- PRICE RANGE -->
            <div class="filter-accordion price-range">
                <h3 class="accordion-header">Price range
                    <span class="accordion-icon"></span>
                </h3>

                <div class="accordion-content">
                    <div class="price-range">
                        <input type="range"
                        data-type="price_min"
                        id="price_min"
                        min="0"
                        max="<?php echo esc_attr($price_max); ?>"
                        step="1000"
                        value="<?php echo esc_attr($price_min); ?>">

                        <input type="range"
                        data-type="price_max"
                        id="price_max"
                        min="0"
                        max="<?php echo esc_attr($price_max); ?>"
                        step="1000"
                        value="<?php echo esc_attr($price_max); ?>">

                        <div class="price-values">
                            <span>JPY <strong id="price-min-label"><?php echo number_format($price_min); ?></strong></span>
                            <span>JPY <strong id="price-max-label"><?php echo number_format($price_max); ?></strong></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- BEDROOMS -->
            <div class="filter-accordion bedrooms">
                <h3 class="accordion-header">
                    No. of bedrooms
                    <span class="accordion-icon"></span>
                </h3>

                <div class="accordion-content">
                    <div class="checkbox-grid">
                        <?php foreach ($bedroom_options as $value => $label) : ?>
                            <div class="ch-item">
                                <input type="checkbox"
                                name="bedrooms[]"
                                data-type="bedrooms-<?php echo esc_attr($value); ?>"
                                id="bedroom-<?php echo esc_attr($value); ?>"
                                value="<?php echo esc_attr($value); ?>"
                                <?php checked(in_array($value, (array) $selected_bedrooms)); ?>>
                                <label for="bedroom-<?php echo esc_attr($value); ?>">
                                    <?php echo esc_html($label); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- AREA -->
            <?php //$display = should_display_base_area_filter($resort) ? 'block' : 'none'; ?>
            <div class="filter-accordion base_area">
                <h3 class="accordion-header">
                    Base area
                    <span class="accordion-icon"></span>
                </h3>
                <div class="accordion-content">
                    <div class="checkbox-list">
                        <?php
                        foreach ($base_areas as $slug => $label) :
                            pre( 'slug' );
                            pre( $slug );
                            pre( 'label' );
                            pre( $label );
                            pre( 'area' );
                            pre( $area );

                            // Check for special slug + area combinations
                            $is_checked = in_array($slug, (array) $selected_areas);
                            
                            if (!$is_checked) {
                                if ($slug === 'niseko-village-higashiyama' && $context_segment === 'niseko-village') {
                                    $is_checked = true;
                                } elseif ($slug === 'happo-one-village' && $context_segment === 'happo') {
                                    $is_checked = true;
                                } elseif ($slug === 'wadano_no_mori' && $context_segment === 'wadano') {
                                    $is_checked = true;
                                } elseif ($slug === 'hirafu_village' && $context_segment === 'hirafu') {
                                    $is_checked = true;
                                }
                            }
                        ?>
                            <div class="ch-item">
                                <input type="checkbox"
                                name="area[]"
                                data-type="area-<?php echo esc_attr($slug); ?>"
                                id="area-<?php echo esc_attr($slug); ?>"
                                value="<?php echo esc_attr($slug); ?>"
                                <?php checked($is_checked); ?>>
                                <label for="area-<?php echo esc_attr($slug); ?>">
                                    <?php echo esc_html($label); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
            </div>

            <!-- ACCOMMODATION TYPE -->
            <div class="filter-accordion type">
                <h3 class="accordion-header">
                    Property type
                    <span class="accordion-icon"></span>
                </h3>

                <div class="accordion-content">
                    <div class="checkbox-list">
                        <?php foreach ($type_options as $value => $label) : 
                            $type_checked = in_array($value, (array) $selected_types) || ($context_segment === $value);
                        ?>
                            <div class="ch-item">
                                <input type="checkbox"
                                name="type[]"
                                data-type="<?php echo esc_attr($value); ?>"
                                id="<?php echo esc_attr($value); ?>"
                                value="<?php echo esc_attr($value); ?>"
                                <?php checked($type_checked); ?>>
                                <label for="<?php echo esc_attr($value); ?>">
                                    <?php echo ucwords(esc_html($label)); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Ski In / Ski Out -->
            <div class="filter-accordion ski-in-ski-out">
                <h3 class="accordion-header">
                    Ski-in ski-out
                    <span class="accordion-icon"></span>
                </h3>

                <div class="accordion-content">
                    <div class="ch-item">
                        <input type="checkbox" id="ski_in_ski_out" data-type="ski_in_ski_out" value="Ski In Ski Out" name="ski_in_ski_out">
                        <label for="ski_in_ski_out">Ski-in ski-out</label>
                    </div>
                </div>
            </div>

            <!-- Ski In / Ski Out -->
            <div class="filter-accordion onsen">
                <h3 class="accordion-header">
                    On-site onsen
                    <span class="accordion-icon"></span>
                </h3>

                <div class="accordion-content">
                    <div class="ch-item">
                        <input type="checkbox" value="onsen onsite" id="onsen" data-type="onsen" name="onsen">
                        <label for="onsen">On-site onsen</label>
                    </div>
                </div>
            </div>

            <!-- Instant Booking -->
            <div class="filter-accordion booking">
                <h3 class="accordion-header">
                    Instant Booking
                    <span class="accordion-icon"></span>
                </h3>
                <div class="accordion-content">
                    <div class="ch-item">
                        <input type="checkbox" id="booking" data-type="booking" name="booking" value="booking">
                        <label for="booking">Instant Booking</label>
                    </div>
                </div>
            </div>

            <!-- Discount -->
            <div class="filter-accordion discount">
                <h3 class="accordion-header">
                    Discount
                    <span class="accordion-icon"></span>
                </h3>

                <div class="accordion-content">
                    <div class="ch-item">
                        <input type="checkbox" id="deals" <?php if( $resort == 'offers' || $area == 'deals' ) checked( true, true, true ); ?> data-type="discount" name="discount" value="discount">
                        <label for="deals">Discount</label>
                    </div>
                </div>
            </div>

            <!-- ACTION BUTTONS -->
            <button type="button" id="apply-filters" class="filter-search-btn">
                Search
            </button>

            <button type="button" id="clear-filters" class="filter-clear-btn">
                Clear All Filters
            </button>

        </div>
    </div>
